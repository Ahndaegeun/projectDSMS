 var cal = new tui.Calendar('#calendar', {
    defaultView: 'month' // monthly view option
  });